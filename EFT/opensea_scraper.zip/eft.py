from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from bs4 import BeautifulSoup
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import csv

hover_element = None
while hover_element is None:
    options = webdriver.ChromeOptions()
    options.add_argument('--headless')
    options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36')
    url = "https://opensea.io/de-DE/assets/ethereum/0xbc4ca0eda7647a8ab7c2061c2e118a18a936f13d/2876"
    driver = webdriver.Chrome(options=options)
    driver.get(url)
    try:
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//div[@data-testid='EventTimestamp']"))
        )
        hover_element = driver.find_elements(By.XPATH, "//div[@data-testid='EventTimestamp']")
    except:
        print("Failed to locate Element")
    hover_elements = driver.find_element(By.XPATH, "//div[@class='EventHistory--Panel']")
    print("Step 1 Success")

for el in hover_element:
    try:
        action = ActionChains(driver)
        action.move_to_element(el).perform()
        driver.implicitly_wait(5)
        html = driver.page_source
        soup = BeautifulSoup(html, "html.parser")
        div = soup.find("div", class_="tippy-content")
        content = div.find_next("span").text
        print(content)
        match = url.split("/")
        temp_d = {
            "id": match[-1],
            "content": content
        }
        with open("buy_history.csv", mode='a+', newline='', encoding='utf-8') as csv_file:
            fieldnames = ['id', 'content']
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            writer.writerow(temp_d)
    except Exception as e:
        print(e)

driver.quit()
